package com.example.canteen_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
